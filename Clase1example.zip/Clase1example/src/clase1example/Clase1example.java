/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase1example;

import javax.swing.JOptionPane;

/**
 *
 * @author charliesalas
 */
public class Clase1example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    /* 
        
    String lectura;
        
    String nombre = " ";
    int edad = 0;
    double salario;
    
    nombre = JOptionPane.showInputDialog("Digite su nombre: ");
    
    lectura = JOptionPane.showInputDialog("Digite su edad: ");
    
    edad = Integer.parseInt(lectura);
    
    lectura = JOptionPane.showInputDialog("Digite su salario");
    
    salario = Double.parseDouble(lectura);
    
    JOptionPane.showMessageDialog (null, "El nombre de la persona es " + nombre + " tiene "+ edad + " anos" + " recibe un salario de: "+ salario);    
   
    */
    
    /* Ejercicio 1 de la clase 1 */
    
    /*
    
    JOptionPane.showMessageDialog(null,"Bienvenido al mundo de Java. Podrás dar solución a muchos problemas.");
    
    */
    
    /* Ejercicio 1, desarrollo 2
    
    String lecture;
    int var1;
    int var2;
    int var3;
    int var4;
    int sume;
    float prom;
    
    lecture = JOptionPane.showInputDialog("Escriba su primer digito: ");
    var1 = Integer.parseInt(lecture);
    lecture = JOptionPane.showInputDialog("Escriba su segundo digito: ");
    var2 = Integer.parseInt(lecture);
    lecture = JOptionPane.showInputDialog("Escriba su tercero digito: ");
    var3 = Integer.parseInt(lecture);
    lecture = JOptionPane.showInputDialog("Escriba su cuarto digito: ");
    var4 = Integer.parseInt(lecture);
    
    sume = var1 + var2 + var3 + var4;
    prom = (var1 + var2 + var3 + var4) / 4 ;
    
    JOptionPane.showMessageDialog(null,"La suma de los numeros digitados son: "+ sume + " El promedio es de: " + prom);
    
    */
    
    /* Ejercicio 3 desarrollo 1 */
    
    /*
    
    
    String lecture;
    String name = "David";
    
    JOptionPane.showMessageDialog(null,"Hola" + " " + name + " " + "bienvenido a este programa desarrollado en JAVA con Netbeans.");
    
    */ 
    
    /* Practica en clase, desarrollo 1 */
    
    /*
    
    String lecture;
    int currentage = 0;
    int projeage = 0;
    
    lecture = JOptionPane.showInputDialog("Digite su edad: ");
    currentage = Integer.parseInt(lecture);
    projeage = currentage + 5;
        JOptionPane.showMessageDialog(null,"Su edad en 5 anios sera de: " + projeage);
    
    */
    
    /* Practica en clase, desarrollo 2 */
    
    /*
    
    String lecture;
    float salary = 0;
    float porG = 0;
    float porA = 0;
    float porD = 0;
    
    lecture = JOptionPane.showInputDialog("Digite su monto de ingreso mensual: ");
    salary = Integer.parseInt(lecture);
    lecture = JOptionPane.showInputDialog("Digite cuanto gasta en comida al mes: ");
    porG = Integer.parseInt(lecture);
    
    porA = ((porG * 100)/salary);
    porD = 100 - porA;
    
    
    JOptionPane.showMessageDialog(null, " Usted gasta en comida un: " + porA + "%" + " Usted tiene un monto disponible a gastar de: " + porD + "%");
    
    */
    
    /* Trabajo extraclase, clase 1 */
    
    String lecture;
    String name       = "Carlos";
    int salaryW       = 76800;
    double salaryM    = 0;
    double timenM     = 4.33 ;
    double deductions = 0.0934;
    double operationD = 0;
    double netsalary   = 0;
    
    salaryM = (salaryW * timenM);        /* Aqui se calcula el salario por mes */
    operationD = (salaryM * deductions); /* Aqui se calcula las deduciones */
    netsalary = salaryM - operationD;
    
    
    JOptionPane.showMessageDialog(null,"Estimado" + " " + name + " el salario de este mes se desglosa de la siguiente manera." + "\n" 
            + "Salario bruto: "+ salaryM + "\n" + "Deducciones: "+ operationD + "\n" + "Salario Neto: " + netsalary);
     
    
    }
    
}
