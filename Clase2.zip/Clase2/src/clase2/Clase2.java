/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase2;

import javax.swing.JOptionPane;

/**
 *
 * @author charliesalas
 */
public class Clase2 {    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /* 1 ejercicio de la practica semana 2
        
        String lecture;
        int age = 0; 
        
        lecture = JOptionPane.showInputDialog("Digite su edad: ");
        
        age = Integer.parseInt(lecture);
        
        if (age >= 18) {
            JOptionPane.showMessageDialog(null, "Usted puede votar!");
        }else 
            JOptionPane.showMessageDialog(null,"Lo lamento usted no es apto para votar");
            
        /* int edad = 20;
        
        if (edad >17){
            System.out.println("Si puede votar.");
            }else
            System.out.println("No puede votar.");
        */
        
          /* 2 Ejercicio semana 2 estructura if
        String lecture;
        int note = 0; 
        
        lecture = JOptionPane.showInputDialog("Digite la nota del curso anterior: ");
        
        note = Integer.parseInt(lecture);
        
        if (note >= 70) {
            JOptionPane.showMessageDialog(null, "Usted paso el curso!");
        }else 
            JOptionPane.showMessageDialog(null,"Lo lamento usted reprobo el curso");
            
        /* int edad = 20;
        
        if (edad >17){
            System.out.println("Si puede votar.");
            }else
            System.out.println("No puede votar.");
         */
        
          
        /* String lecture;
        int day=0;
        
        lecture = JOptionPane.showInputDialog("Bienvenido! Digite el numero del dia: ");
        
        day = Integer.parseInt(lecture);
        
        switch (day) {
            case 1:
                JOptionPane.showMessageDialog(null,"Hoy es Lunes");
                break;
            case 2:
                JOptionPane.showMessageDialog(null,"Hoy es Martes");
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"Hoy es Miercoles");
                break;
            case 4:
                JOptionPane.showMessageDialog(null,"Hoy es Jueves");
                break;
            case 5:
                JOptionPane.showMessageDialog(null,"Hoy es Viernes");
                break;
            case 6:
                JOptionPane.showMessageDialog(null,"Hoy es Sabado");
                break;
            case 7:
                JOptionPane.showMessageDialog(null,"Hoy es Domingo");
                break;
        */
        
         /* Ejercicio 1 de la practica compuesta de if.
        
        String lecture;
        int day=0;
        
        lecture = JOptionPane.showInputDialog("Bienvenido! Digite el numero del dia: ");
        
        day = Integer.parseInt(lecture);
        
        switch (day) {
            case 1:
                JOptionPane.showMessageDialog(null,"Hoy es Lunes");
                break;
            case 2:
                JOptionPane.showMessageDialog(null,"Hoy es Martes");
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"Hoy es Miercoles");
                break;
            case 4:
                JOptionPane.showMessageDialog(null,"Hoy es Jueves");
                break;
            case 5:
                JOptionPane.showMessageDialog(null,"Hoy es Viernes");
                break;
            case 6:
                JOptionPane.showMessageDialog(null,"Hoy es Sabado");
                break;
            case 7:
                JOptionPane.showMessageDialog(null,"Hoy es Domingo");
                break;
        */
         
        /* Ejercicio 2 de la practica compuesta de if.
         
        String lecture;
        int day=0;
        
        lecture = JOptionPane.showInputDialog("Bienvenido! Digite el numero del dia: ");
        
        day = Integer.parseInt(lecture);
        
        switch (day) {
            case 1:
                JOptionPane.showMessageDialog(null,"Hoy es Lunes, dia laboral");
                break;
            case 2:
                JOptionPane.showMessageDialog(null,"Hoy es Martes, dia laboral");
                break;
            case 3:
                JOptionPane.showMessageDialog(null,"Hoy es Miercoles, dia laboral");
                break;
            case 4:
                JOptionPane.showMessageDialog(null,"Hoy es Jueves, dia laboral");
                break;
            case 5:
                JOptionPane.showMessageDialog(null,"Hoy es Viernes, dia laboral");
                break;
            case 6:
                JOptionPane.showMessageDialog(null,"Hoy es Sabado, dia libre");
                break;
            case 7:
                JOptionPane.showMessageDialog(null,"Hoy es Domingo, dia libre");
                break;
        */
        
        /* Ejercicio 3 de la practica 2 if compuestos.
        
        String Comperative;
        int dig1 = 0;
        int dig2 = 0;
        int dig3 = 0;
        int dig4 = 0;

        Comperative = JOptionPane.showInputDialog("Digite el primer numero: ");
        dig1 = Integer.parseInt(Comperative);
        Comperative = JOptionPane.showInputDialog("Digite el segundo numero: ");
        dig2 = Integer.parseInt(Comperative);
        Comperative = JOptionPane.showInputDialog("Digite el tercero numero: ");
        dig3 = Integer.parseInt(Comperative);
        Comperative = JOptionPane.showInputDialog("Digite el cuarto numero: ");
        dig4 = Integer.parseInt(Comperative);
        
        if ( dig1 > dig2 && dig2 < dig3 && dig3 < dig4){
        JOptionPane.showMessageDialog(null, "El numero mayor es: " + dig1);
        }else{
            if ( dig1 < dig2 && dig2 > dig3 && dig3 < dig4){
            JOptionPane.showMessageDialog(null, "El numero mayor es: " + dig2);
            }else{
                if (dig1 < dig2 && dig2 < dig3 && dig3 > dig4) {
                JOptionPane.showMessageDialog(null, "El numero mayor es: " + dig3);
                }else{
                    if (dig1 < dig2 && dig2 < dig3 && dig3 < dig4) {
                    JOptionPane.showMessageDialog(null, "El numero mayor es: " + dig4);
                {
                    
                    */
        
        /* Trabajo extra clase */ 
        
        String lecture;
        int anti        = 0;
        int cntxS       = 0;
        int prcxH       = 0;
        double bonoA    = 0.20;
        double timeM    = 4.33;
        double salaryB  = 0;
        double salarywB = 0;
        
        lecture = JOptionPane.showInputDialog("Cuantos anios tiene en la empresa:  ");
        anti = Integer.parseInt(lecture);
        lecture = JOptionPane.showInputDialog("Cuantas horas trabaja por semana:  ");
        cntxS = Integer.parseInt(lecture);
        lecture = JOptionPane.showInputDialog("Cuanto le pagan por hora? :  ");
        prcxH = Integer.parseInt(lecture);
        
        timeM = (cntxS * timeM);
        salaryB = (timeM * prcxH);
        
        if (anti < 10) {
          
        JOptionPane.showMessageDialog(null,"Su salario bruto es de: " + salaryB);
        
        if (anti >= 10) {
            bonoA = (salaryB * bonoA);
            salarywB = (salaryB + bonoA);
            JOptionPane.showMessageDialog(null,"Por su gran esfuerzo de llevar " + anti + "le daremos un bono!" + salarywB);
            
            }  
        }
    }       
}
